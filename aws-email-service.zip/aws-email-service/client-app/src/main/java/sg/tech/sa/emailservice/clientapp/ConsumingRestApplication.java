package sg.tech.sa.emailservice.clientapp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpHeaders;
import sg.tech.sa.emailservice.clientapp.dto.NotificationDto;

import java.net.URI;
import java.net.URISyntaxException;

@SpringBootApplication
public class ConsumingRestApplication {

	static final String API_URL = "https://u0ekkfbqxg.execute-api.ap-southeast-1.amazonaws.com/uat/v1/enququeemail";
	static final String SENDER = "arun2808@gmail.com";
	static final String RECIPIENT = "arun2808@gmail.com";
	static final String SUBJECT = "Amazon SES test (SMTP interface accessed using Java)";
	static final String BODY = String.join(
			System.getProperty("line.separator"),
			"<h1>Amazon SES SMTP Email Test</h1>",
			"<p>This email was sent with Amazon SES using the ",
			"<a href='https://github.com/javaee/javamail'>Javamail Package</a>",
			" for <a href='https://www.java.com'>Java</a>."
	);

	private static final Logger log = LoggerFactory.getLogger(ConsumingRestApplication.class);

	@Autowired
	private RestTemplate restTemplate;

	public static void main(String[] args) {
		SpringApplication.run(ConsumingRestApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	@Bean
	public CommandLineRunner postRequest() throws URISyntaxException {
		return args -> {
			final URI uri = new URI(API_URL);
			final NotificationDto notificationDto = new NotificationDto(SENDER, RECIPIENT, SUBJECT, BODY);
			final HttpHeaders headers = new HttpHeaders();
			//headers.set("X-COM-PERSIST", "true");
			final HttpEntity<NotificationDto> request = new HttpEntity<>(notificationDto, headers);
			final ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request, String.class);
			System.out.println("Status" +result.getStatusCodeValue());
			System.out.println("Body" +result.getBody());
			log.info("Completed");
		};
	}
}
