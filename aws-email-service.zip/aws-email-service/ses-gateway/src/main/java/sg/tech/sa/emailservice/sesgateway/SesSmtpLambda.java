package sg.tech.sa.emailservice.sesgateway;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sg.tech.sa.emailservice.sesgateway.model.NotificationDto;
import sg.tech.sa.emailservice.sesgateway.service.SendMailService;

public class SesSmtpLambda implements RequestHandler<SQSEvent, String> {
    static final String REGION = System.getenv("REGION");
    static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private static final Logger logger = LoggerFactory.getLogger(RequestHandler.class);

    @Override
    public String handleRequest(final SQSEvent event, final Context context) {
        logger.info("EVENT: " + gson.toJson(event));
        for (final SQSEvent.SQSMessage sqsMessage : event.getRecords()) {
            processMessage(sqsMessage);
        }
        return "200 OK";
    }

    private void processMessage(final SQSEvent.SQSMessage sqsMessage) {
        final SendMailService sendMailService = new SendMailService();
        final NotificationDto notificationDto = gson.fromJson(sqsMessage.getBody(), NotificationDto.class);
        sendMailService.send(REGION, notificationDto);
    }

}

