package sg.tech.sa.emailservice.sesgateway.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sg.tech.sa.emailservice.sesgateway.model.NotificationDto;
import software.amazon.awssdk.services.ses.SesClient;
import software.amazon.awssdk.services.ses.model.*;
import software.amazon.awssdk.regions.Region;

public class SendMailService {

    private static final Logger logger = LoggerFactory.getLogger(SendMailService.class);
    public void send(final String region, final NotificationDto notificationDto) {
        final SesClient sesClient = SesClient.builder().region(Region.of(region)).build();
        final Destination destination = Destination.builder().toAddresses(notificationDto.getRecipient()).build();
        final Content content = Content.builder().data(notificationDto.getBody()).build();
        final Content sub = Content.builder().data(notificationDto.getSubject()).build();
        final Body body = Body.builder().html(content).build();
        final Message msg = Message.builder().subject(sub).body(body).build();
        final SendEmailRequest emailRequest = SendEmailRequest.builder().destination(destination).message(msg).source(notificationDto.getSender()).build();
        logger.info("Attempting to send an email through Amazon SES " + "using the AWS SDK for Java...");
        sesClient.sendEmail(emailRequest);
        logger.info("Email sent!");
    }

}